#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <mysql/mysql.h> // MySQL 헤더 파일 추가

#define MAX_NAME_LENGTH 40
#define MAX_FRAMES 10

typedef struct {
  int firstRoll;
  int secondRoll;
  int score;
  int isStrike;
  int isSpare;
} Frame;

typedef struct {
  MYSQL *conn;
  const char *host;
  const char *user;
  const char *pass;
  const char *db;
  unsigned int port;
} MySQLConnection;
