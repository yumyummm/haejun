#include "bowlingGame.h"

int main() {
    char playerName[MAX_NAME_LENGTH];
    srand(time(NULL));
    MySQLConnection mysql;
  
    if (!initMySQL(&mysql)) {
      fprintf(stderr, "MySQL 초기화 실패\n");
      return 1;
    }
  
    startScreen(playerName);
    playGame(playerName, &mysql);
    closeMySQL(&mysql);
    return 0;
  }